// var fs = null;
// var FOLDERNAME = 'testchromeapp';

var service = analytics.getService('asana-chrome-app');
window.tracker = service.getTracker('UA-18735851-11'); 

function onError(e) {
  console.error('Error!', e);
}


function storeErrorCheck() {
	if(typeof chrome.runtime.lastError !== 'undefined') {
		console.error('Oops something went wrong while saving or getting locally.', chrome.runtime.lastError);
	}
}

function storeValue(key, value, callback) {
	var toStore = {};
	toStore[key] = value;
	chrome.storage.local.set(toStore, function() {
		storeErrorCheck();
		if(typeof callback !== 'undefined')
			callback();
	});
}

function getValue(key, callback) {
	chrome.storage.local.get(key, function(store) {
		storeErrorCheck();
		callback(store);
	});
}

// function writeFile(blob) {
//   if (!fs) {
//     return;
//   }

//   fs.root.getDirectory(FOLDERNAME, {create: true}, function(dirEntry) {
//     dirEntry.getFile(blob.name, {create: true, exclusive: false}, function(fileEntry) {
//       // Create a FileWriter object for our FileEntry, and write out blob.
//       fileEntry.createWriter(function(fileWriter) {
//         fileWriter.onerror = onError;
//         fileWriter.onwriteend = function(e) {
//           console.log('Write completed.');
//         };
//         fileWriter.write(blob);
//       }, onError);
//     }, onError);
//   }, onError);
// }

// document.addEventListener('DOMContentLoaded', function(e) {
//   console.log("Filesystem online.");

//   // FILESYSTEM SUPPORT --------------------------------------------------------
//   window.webkitRequestFileSystem(TEMPORARY, 1024 * 1024, function(localFs) {
//     fs = localFs;
//   }, onError);
//   // ---------------------------------------------------------------------------
// });
'use strict';


// Declare app level module which depends on views, and components
angular.module('asanaChromeApp', ['restangular', 'base64','cgNotify','ngSanitize']);

angular.module('asanaChromeApp').controller('MainController', ['$scope','AsanaService', '$http', 'notify', function($scope, AsanaService, $http, notify) {
	$scope.asana = AsanaService;
	$scope.taskFilterCompleted = 'all';
	$scope.taskFilter = {};

	$scope.taskContext = [];
	$scope.contextText = "";
	$scope.tasks = [];

	$scope.intervalTime = 1000 * 60 * 5; // 5 minutes
	$scope.lastRefresh = (new Date()).getTime();

	var intervalCallback = function(data) {
		if(data.length > 0) {
			var items = [];
			for(var x = 0; x < data.length; x++) {
				var obj = data[x];
				items.push({ title: obj.name, message: '' });
			}

			chrome.notifications.create('updatedTasks', {
				iconUrl: 'images/icon-64.png',
				type: 'list',
				title: data.length + ' task(s) have been updated',
				message: '',
				isClickable: false,
				items: items
			}, function() {});
		}
	};

	$scope.interval = setInterval(function() {
		var date = new Date($scope.lastRefresh)
		AsanaService.autoRefresh(date.toISOString(), intervalCallback);
		$scope.lastRefresh = (new Date()).getTime();
		storeValue('lastRefresh', $scope.lastRefresh);
	}, $scope.intervalTime);

	/*
		Get stuff from localstorage
	*/
	getValue('lastRefresh', function(value) {
		if(typeof value.lastRefresh !== 'undefined') {
			$scope.lastRefresh = value.lastRefresh;
		}
	});

	// really ugly, need to use promises!
	getValue('taskContext', function(valForContext) {
		if(typeof valForContext.taskContext !== 'undefined') {
			$scope.taskContext = valForContext.taskContext;
		}

		getValue('contextText', function(valForText) {
			if(typeof valForText.contextText !== 'undefined') {
				$scope.contextText = valForText.contextText;
			}

			getValue('apiKey', function(valForKey) {
				if(typeof valForKey.apiKey !== 'undefined') {
					$scope.apiKey = valForKey.apiKey;
					AsanaService.init(valForKey.apiKey, $scope);
				} else {
					notify({ message:'API Key is not defined, please configure it from settings.', classes: 'alert-custom' } );
				}
			});
		});
	});

	getValue('taskFilter', function(value) {
		if(typeof value.taskFilter !== 'undefined') {
			$scope.taskFilter = value.taskFilter;
			if(typeof value.taskFilter.completed !== 'undefined') {
				if(value.taskFilter.completed) 
					$scope.taskFilterCompleted = 'completed';
				else
					$scope.taskFilterCompleted = 'todo';
			}
		}
	});

	/*
		Setup your private functions
	*/

	var setTaskWithContext = function(taskId) {
		var task = AsanaService.findTask(taskId);
		if($scope.taskContext.length <= 0 || task === null) {
			$scope.tasks = AsanaService.tasks;
		} else {
			$scope.contextText = task.name;
			$scope.tasks = task.subtasks;	
		}

		storeValue('taskContext', $scope.taskContext);
		storeValue('contextText', $scope.contextText);
	}

	$scope.$watch('asana.tasks', function() {
		if($scope.taskContext.length > 0) {
			setTaskWithContext($scope.taskContext[$scope.taskContext.length - 1]);
		} else {
			setTaskWithContext(null);
		}
	});

	var watchers = []; // used to watch over subtask changes esp for refresh.
	// refines the task scope to taskId sent
	$scope.expandContext = function(taskId) {
		tracker.sendEvent('task', 'subtask-drill-down', $scope.taskContext.length);
		$scope.taskContext.push(taskId);
		watchers.push($scope.$watchCollection(function() {
			return AsanaService.findTask(taskId);
		}, function() {
			setTaskWithContext(taskId);
		}));
	};

	// reduces the scope to the parent, or toplevel
	$scope.reduceContext = function() {
		tracker.sendEvent('task', 'subtask-move-up', $scope.taskContext.length);
		$scope.taskContext.pop();
		(watchers.pop())(); // remove the watcher since its no longer getting observed
		setTaskWithContext($scope.taskContext[$scope.taskContext.length - 1]);
	};

	var resetContext = function() {
		for(var indexW in watchers) {
			var watcher = watchers[indexW];
			watcher(); // unwatch it
		}

		$scope.taskContext = [];
		$scope.contextText = '';		
		setTaskWithContext(null);
	};

	$scope.refresh = function() {
		tracker.sendEvent('app', 'refresh');
		if($scope.taskContext.length > 0) {
			AsanaService.fetchTaskDetails($scope.taskContext[$scope.taskContext.length - 1], true);	
		} else {
			AsanaService.refresh(false);
		}
	};

	$scope.changeWorkspace = function(workspace) {
		tracker.sendEvent('app', 'changeWorkspace');
		resetContext();
		AsanaService.selectWorkspace(workspace);
	}

	$scope.changeProject = function(project) {
		tracker.sendEvent('app', 'changeProject');
		resetContext();
		AsanaService.selectProject(project);
	}

	$scope.saveApiKey = function(apiKey) {
		tracker.sendEvent('app', 'updateAPIKey');
		if(apiKey !== '') {
			storeValue('apiKey', apiKey, function() {
				console.log('APIKey updated.')
			});
		}
	};

	$scope.adjustFilter = function() {
		tracker.sendEvent('app', 'adjustFilter');
		if($scope.taskFilterCompleted === 'todo') {
			$scope.taskFilter['completed'] = false;
		} else if($scope.taskFilterCompleted === 'completed') {
			$scope.taskFilter['completed'] = true;
		} else if($scope.taskFilterCompleted === 'all') {
			delete $scope.taskFilter['completed'];
		}

		if($scope.taskFilterAssigned == 0) {
			delete $scope.taskFilter['assignee'];
		} else {
			AsanaService.selectUser($scope.taskFilterAssigned);
			$scope.taskFilter['assignee'] = $scope.taskFilterAssigned;
		}

		storeValue('taskFilter', $scope.taskFilter);
	}

	window.tracker.sendAppView('MainView');
}]);
angular.module('asanaChromeApp').
controller('ItemController', ['$scope', 'AsanaService', function($scope, AsanaService) {
	$scope.showDetails = false;
	$scope.asana = AsanaService;

	$scope.addStory = function(taskId) {
		tracker.sendEvent('task', 'item', 'commented');
		var commentField = $('#comment' + taskId);
		$scope.asana.commentOnTask(taskId, commentField.val());
		commentField.val('');
	};

	$scope.expandTasks = function(taskId) {
		
		$scope.$parent.expandContext(taskId);
	}

	$scope.toggle = function(taskId) {
		tracker.sendEvent('task', 'item', 'expand');
		$scope.asana.fetchTaskDetails(taskId, false);
		if($scope.showDetails) $scope.showDetails = false;
		else $scope.showDetails = true;
	};

	// TODO: Extend as date object
	var convertStringToDate = function(dateString) {
		if(!dateString) 
			return false;

		//2014-11-17
		var dateComps = dateString.split('-');
		if(dateComps.length !== 3) 
			return false;

		//new Date(year, month, day, hours, minutes, seconds, milliseconds);
		return new Date(dateComps[0], parseInt(dateComps[1]) - 1, dateComps[2], 0, 0, 0, 0, 0);
	};

	$scope.hasDeadlinePassed = function(deadline) {
		var date = convertStringToDate(deadline);
		if(!date)
			return false;

		if(date.getTime() > (new Date()).getTime()) 
			return false;

		return true;
	};

	$scope.isDeadlineUpcoming = function(deadline) {
		var date = convertStringToDate(deadline);
		if(!date)
			return false;

		var diff = (date.getTime() - (new Date()).getTime());
		if(diff > 0 && diff < 86400000) 
			return true;

		return false;
	}


}]);
angular.module('asanaChromeApp').
directive('item', function() {
	return {
		restrict: 'A',
		templateUrl: 'views/item.html',
		scope: {
        	item: '='
      	},
      	controller: 'ItemController'
	};
});
angular.module('asanaChromeApp').
service('AsanaService', ['Restangular','$base64', 'notify', function(Restangular, $base64, notify) {

	var storeKey = 'asanaStore';
	this.me = {};
	this.team = [];
	this.workspaces = [];
	this.projects = [];
	this.tasks = []; // stories reside inside their respective tasks
	this.loading = 0;
	
	var _this = this;

	// default error handling
	Restangular.setErrorInterceptor(function(response, deferred, responseHandler) {
    	_this.loading -= 1;
	    console.error('Request failed with status: ', response);

	    if(typeof response.data !== 'undefined' && typeof response.data.errors !== 'undefined') {
	    	tracker.sendEvent('app', 'error', response.data.errors[0].message);
	    	notify({ message:'Error from Asana: ' + response.data.errors[0].message, classes: 'alert-custom' } );
	    } else {
	    	tracker.sendEvent('app', 'error', response.statusText);
	    	notify({ message:'Unexpected error: ' + response.statusText, classes: 'alert-custom' } );
	    }

	    return true; // error not handled
	});

	this.selectUser = function(userId) {
		for(var x = 0; x < _this.team; x++) {
			_this.team[x].isSelected = _this.team[x].id == userId;
		}
		_this.sync();
	};

	this.selectWorkspace = function(workspaceId) {
		_this.loading += 2;
		for(var x = 0; x < _this.workspaces.length; x++) {
			_this.workspaces[x]['isSelected'] = (workspaceId == _this.workspaces[x].id);
		}

		Restangular.one('workspaces/' + workspaceId + '/projects').get().then(function(response) {
			_this.loading -= 1;
			_this.projects = response.data;
			_this.selectProject(response.data[0].id);
		});

		Restangular.one('workspaces', workspaceId).one('users').get().then(function(response) {
			_this.loading -= 1;
			var users = [];
			users.push({
				id: '0',
				name: 'Show all',
				isSelected: true
			});

			for(var x = 0; x < response.data.length; x++) {
				response.data[x].isSelected = false; 
				users.push(response.data[x]);
			}
			_this.team = users;
			_this.sync();
		});
	};

	this.selectProject = function(projectId) {
		_this.loading += 1;
		for(var x = 0; x < _this.projects.length; x++) {
			_this.projects[x]['isSelected'] = (projectId == _this.projects[x].id);
		}

		Restangular.one('projects/' + projectId + '/tasks?opt_fields=assignee.name,assignee,completed,due_on,name,notes').get().then(function(response) {
			_this.loading -= 1;
			_this.tasks = response.data;
			_this.sync(); // done at the end (when tasks are fetched and on each item)
		});
	};

	var deepFind = function(tasks, taskId) {
		if(typeof tasks !== 'undefined' && tasks.length > 0 && taskId !== null) {
			for(var x = 0; x < tasks.length; x++) {
				var task = tasks[x];
				var subtask = deepFind(task.subtasks, taskId);
				if(subtask !== null) {
					return subtask;
				}

				if(task.id === taskId) {
					return task;
				}
			}
		}
		return null;
	};

	this.findTask = function(taskId) {
		return deepFind(_this.tasks, taskId);
	};

	this.fetchTaskDetails = function(taskId, force) {
		var task = _this.findTask(taskId);
		if(task === null) {
			tracker.sendEvent('app', 'error', 'Unable to find task ID.');
			console.error('Unable to find task with ID', taskId);
			notify({ message:'Oops, cant to find task ID, try refreshing?' , classes: 'alert-custom' } );
			return;
		}

		if(typeof task.stories !== 'undefined' && !force) return; // already fetched before.
		_this.loading += 2;
		Restangular.one('tasks', task.id).one('stories').get().then(function(response) {
			_this.loading -= 1;
			task.stories = response.data;
			_this.sync();
		});

		Restangular.one('tasks', task.id).one('subtasks?opt_fields=assignee.name,assignee,completed,due_on,name,notes').get().then(function(response) {
			_this.loading -= 1;
			task.subtasks = response.data;
			_this.sync();
		});
	};

	this.getActiveProject = function() {
		for(var x = 0; x < _this.projects.length; x++) {
			var project = _this.projects[x];
			if(project.isSelected) {
				return project;
			}
		}		
		return _this.projects[0];
	};

	this.refresh = function(refreshEverything) {
		if(refreshEverything) {
			_this.getMeData();
		} else {
			var activeProject = _this.getActiveProject();
			_this.selectProject(activeProject.id);
		}
	};

	this.autoRefresh = function(since, callback) {
		var activeProject = _this.getActiveProject();
		Restangular.one('tasks?opt_fields=assignee.name,assignee,completed,due_on,name,notes&project=' + activeProject.id + '&modified_since=' + since).get().then(function(response) {
			for(var x = 0; x < response.data.length; x++) {
				var updatedTask = response.data[x];
				var actualTask = _this.findTask(updatedTask.id);

				if(actualTask === null) { // Task not found, just add it in
					if(!actualTask.parent) {
						_this.tasks.push(updatedTask);
					}
				} else {
					actualTask.name = updatedTask.name;
					actualTask.due_on = updatedTask.due_on;
					actualTask.notes = updatedTask.notes;
					actualTask.completed = updatedTask.completed;
					actualTask.assignee = updatedTask.assignee;
				}
			}
			_this.sync();
			if(callback)
				callback(response.data);
		});
	}
	
	this.sync = function() {
		var data = {
			me: _this.me,
			team: _this.team,
			workspaces: _this.workspaces,
			projects: _this.projects,
			tasks: _this.tasks
		};

		storeValue(storeKey, data, function() {
			console.log('Sync complete.');
		});
	};

	this.getMeData = function() {
		_this.loading += 1;
		Restangular.one('users/me').get().then(function(response){
			_this.loading -= 1;
			_this.me = response.data;
			_this.workspaces = response.data.workspaces;
			delete _this.me.workspaces; // to avoid collisions
			_this.selectWorkspace(_this.workspaces[0].id); // fetch projects for the first workspace
		});
	};

	this.init = function(apiKey, scope) { // scope sent in to update the view
		
		Restangular.setDefaultHeaders({'Authorization': 'Basic ' + $base64.encode(apiKey + ':') });
		Restangular.setBaseUrl('https://app.asana.com/api/1.0/');
		getValue(storeKey, function(store) {
			if(typeof store[storeKey] === 'undefined') {
				_this.getMeData();
			} else {
				var asana = store[storeKey];
				console.log("Fetched data locally:", asana);
				scope.$apply(function() {
					_this.me = asana.me;
					_this.team = asana.team;
					_this.workspaces = asana.workspaces;
					_this.projects = asana.projects;
					_this.tasks = asana.tasks;
				});
			}
		});
	};

	this.toggleTaskComplete = function(taskId, completed) {
		_this.loading += 1;
		tracker.sendEvent('task', 'completed', completed);
		Restangular.one('tasks', taskId).put({ completed: completed}).then(function(response) {
			_this.loading -= 1;
		});
	};

	this.addStoryToTask = function(taskId, story) {
		for(var x = 0; x < _this.tasks.length; x++) {
			var task = _this.tasks[x];
			if(task.id == taskId) {
				if(typeof task.stories !== 'undefined') {
					task.stories.push(story);
				} else {
					task.stories = [story];
				}
			}
		}
	};

	this.commentOnTask = function(taskId, comment) {
		_this.loading += 1;
		tracker.sendEvent('task', 'comment');
		Restangular.one('tasks', taskId).customPOST({}, 'stories', { text: comment }).then(function(response) {
			_this.loading -= 1;
			_this.addStoryToTask(taskId, response.data);
		});
	};

}]);
/*
	Converts the assignee id into the user name initals
*/

angular.module('asanaChromeApp').
filter('initials', function() {
  return function(name) {
  	if(typeof name !== 'undefined' && name.length > 0) {
  		var namePieces = name.split(' ');
		var initials = '';
		for(var index in namePieces) {
			var word = namePieces[index];
			initials += word[0];
		}
		return initials.substring(0,2);
  	}
  	
    return "";
  };
});

/*
	Converts the attachment to link
*/
angular.module('asanaChromeApp').
filter('attachment', function() {
  return function(storyText) {
  	
  	if(storyText.indexOf('attached') !== -1) {
  		var url = storyText.match(/http.*/gm);
  		if(url.length > 0)
  			storyText = storyText.replace(url, '<a href="' + url[0] + '" target="_blank">this file</a>');
  	}
    return storyText;
  };
});
